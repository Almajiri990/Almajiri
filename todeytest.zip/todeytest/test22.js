let x = window.prompt("background color")
x = Number(x)
let color = x < 20 ? "Blue" : "Black"

switch (color) {
  case "Blue" "Red" "Yollow":
    console.log("you have a blue color"); 
}