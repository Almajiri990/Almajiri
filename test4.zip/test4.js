const number = 27;
const cubeRoot = Math.cbrt(number);
console.log(`the cube root is: ${cubeRoot}`);